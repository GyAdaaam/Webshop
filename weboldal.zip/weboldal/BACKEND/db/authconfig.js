// A biztonsági kulcs.

module.exports={
    secret:"teleki-secret-key"
}